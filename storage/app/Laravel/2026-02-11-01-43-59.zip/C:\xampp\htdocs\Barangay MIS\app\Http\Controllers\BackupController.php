<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class BackupController extends Controller
{
    public function runBackup(Request $request)
    {
        $request->validate([
            'type' => 'required|string|in:full,database,files',
        ]);

        $backupType = $request->input('type');

        try {
            // Run the backup
            if ($backupType === 'full') {
                Artisan::call('backup:run');
            } elseif ($backupType === 'database') {
                Artisan::call('backup:run', ['--only-db' => true]);
            } elseif ($backupType === 'files') {
                Artisan::call('backup:run', ['--only-files' => true]);
            }

            // Get the latest backup file from Spatie's default disk
            $files = collect(Storage::disk('local')->files('laravel-backups'))->sortDesc();
            $latestFile = $files->first();

            if (!$latestFile) {
                return response()->json([
                    'success' => false,
                    'message' => 'Backup completed but file not found.',
                ], 500);
            }

            return response()->json([
                'success' => true,
                'message' => 'Backup completed successfully!',
                'data' => [
                    'filename' => basename($latestFile),
                    'path' => $latestFile,
                    'size' => Storage::disk('local')->size($latestFile),
                    'created_at' => Carbon::now()->toDateTimeString(),
                    'type' => $backupType,
                ]
            ]);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Backup failed: ' . $e->getMessage()], 500);
        }
    }
    public function index(Request $request)
    {
        // if ($request->user()->role !== 'ADMIN') {
        //     return response()->json([
        //         'message' => 'Unauthorized. Admin access only.'
        //     ], 403);
        // }

        $disk = Storage::disk(config('backup.backup.destination.disks')[0]);
        $files = $disk->files(config('backup.backup.name'));

        $backups = collect($files)->map(function ($file, $index) use ($disk) {
            return [
                'id' => $index + 1,
                'filename' => basename($file),
                'type' => str_contains($file, 'db') ? 'database' :
                          (str_contains($file, 'files') ? 'files' : 'full'),
                'size' => round($disk->size($file) / 1024 / 1024, 2) . ' MB',
                'created_at' => Carbon::createFromTimestamp(
                    $disk->lastModified($file)
                )->format('Y-m-d H:i:s'),
                'status' => 'completed',
            ];
        })->values();

        return response()->json([
            'data' => $backups
        ]);
    }

    public function downloadBackup($id)
    {
        $file = "backups/backup_{$id}.txt"; // or .zip/.sql depending on your naming
        if (!Storage::disk('local')->exists($file)) {
            return response()->json(['error' => 'Backup file not found'], 404);
        }

        return response()->download(storage_path("app/{$file}"));
    }


}
