<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreBarangayBusinessClearanceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'brgyBusinessNo' => 'nullable|string|max:50',
            'requester_type' => 'required|string|max:50',
            'issuedDate' => 'nullable|date',
            'prefix' => 'nullable|string|max:10',
            'surname' => 'nullable|string|max:100',
            'firstname' => 'nullable|string|max:100',
            'middlename' => 'nullable|string|max:100',
            'ext' => 'nullable|string|max:10',
            'businessName' => 'nullable|string|max:200',
            'businessType' => 'nullable|string|max:100',
            'businessDetails' => 'nullable|string|max:500',
            'capital' => 'nullable|numeric|min:0',
            'houseBlockLotNo' => 'nullable|string|max:50',
            'street' => 'nullable|string|max:100',
            'zone' => 'nullable|string|max:50',
            'orNo' => 'nullable|string|max:50',
            'inspectedBy' => 'nullable|string|max:100',
            'dateOfInspection' => 'nullable|date',
            'inspectionRemarks' => 'nullable|string|max:500',
            'inspectedRemarks' => 'nullable|string|max:500',
            'dateInspected' => 'nullable|date',
            'inspectedNote' => 'nullable|string|max:500'
            
        ];
    }
}

